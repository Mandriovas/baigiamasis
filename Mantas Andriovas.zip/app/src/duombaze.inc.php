<?php

    $dbServer = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "projektas";

    $conn = mysqli_connect($dbServer,$dbUsername,$dbPassword,$dbName);