<?php

    if(isset($_POST['submit'])) {
        include_once ('duombaze.inc.php');
        $vardas = trim($_POST['name']);
        $email = trim($_POST['email']);
        $message = trim($_POST['message']);

        if(empty($vardas) || empty($email) || empty($message)) {
            header("Location: ../../public/index.php?form=empty");
            exit();
        } else {
            if(!preg_match("/^[a-zA-Z]*$/",$vardas)) {
                header("Location: ../../public/index.php?form=invalid");
                exit();
            } else {
                if(!filter_var($email , FILTER_VALIDATE_EMAIL)) {
                    header("Location: ../../public/index.php?form=invalidemail");
                    exit();
                } else {
                        $sql = "INSERT INTO kontaktine (vardas,email,message) VALUES ('$vardas', '$email', '$message');";
                        mysqli_query($conn, $sql);
                        header("Location: ../../public/index.php?form=successs");
                        exit();
                }
            }

        }

    } else {
        header("Location: ../../public/index.php");
        exit();
    }

?>