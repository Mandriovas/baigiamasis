<header class="site-header">
                <div class="container flex-container">
                    <div class="logo">
                            <a href="../public/index.php"><img src="../app/images/logo.png" alt="Logotipas"></a>
                    </div>

                    <!--Pagrindinis meniu -->
                    <nav id="navbaras" class="navigacija">
                        <ul class="flex-container">
                            <li><a href="/">Home </a></li>
                            <li><a href="#feutures">Feutures </a></li>
                            <li><a href="#works">Work </a></li>
                            <li><a href="#team">Team </a></li>
                            <li><a href="#facts">Prices </a></li>
                            <li><a href="#contact">Contact </a></li>
                        </ul>
                    </nav>
                    <nav class="mobile-nav">
                        <ul id="mMenu" class="flex-container">
                            <li><a href="/">Home</a></li>
                            <li><a href="#feutures">Feutures</a></li>
                            <li><a href="#works">Work</a></li>
                            <li><a href="#team">Team</a></li>
                            <li><a href="#facts">Prices</a></li>
                            <li><a href="#contact">Contact</a></li>
                        </ul>
                        <a id="m-toggle" href="javascript:void(0);" class="icon" onclick="hamburgerMenu()">
                                <i class="fa fa-bars"></i>
                            </a>
                    </nav>
                     <!--/Pagrindinis meniu -->
                </div>
        </header>