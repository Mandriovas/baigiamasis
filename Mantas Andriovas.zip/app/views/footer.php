<footer class="footeris">
                <div class="container">
                    <div id="footeris">
                        <div class="logo-info">
                            <img src="../../app/images/footerioLogo.png" alt="">
                            <p>eusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        </div>
                        <div class="subscribe">
                            <h3>Subscribe</h3>
                            <div class="subscribe-laukas">
                                <input type="email" id="subscribe">
                                <button type="button" class="subscribe-mygtukas"><i class="fas fa-long-arrow-alt-right"></i></button>
                            </div>
                            <p>eusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                        </div>
                        <div class="explore">
                            <h3>Explore</h3>
                            <ul>
                                <li><a href=""> Inside Us</a></li>
                                <li><a href="">Flickr</a></li>
                                <li><a href="">Google</a></li>
                                <li><a href="">Forum</a></li>
                            </ul>
                        </div>
                        <div class="support">
                            <h3>Support</h3>
                            <ul>
                                <li><a href="">Contact Us</a></li>
                                <li><a href="">Market Blog</a></li>
                                <li><a href="">Help Center</a></li>
                                <li><a href="">Pressroom</a></li>
                            </ul>
                        </div>
                    </div>
                    <p class="copyright">Copyright &copy 2021 Themefisher. All rights reserved. Designed & developed by Themefisher.</p>
                </div>
            </footer>
            <a href="javascript:void(0);" id="back-top" style="display: block;">
                <i class="fa fa-angle-up fa-3x"></i>
            </a>