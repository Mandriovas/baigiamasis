<main>

<section class="karusele">
    <div id="karusele">
        <div class="karuseles-vidus">
            <div class="karuseles-ft">
                <img src="../app/images/banner.jpg" alt="Banneris">
            </div>
            <div class="centruotas">
                <h2 class="nusileidzia animacija">Meet <span class="bold-upper">TEAM</span>  ! </h2>
                <h3 class="is-kaires animacija"><span class="color">/creative</span> on page template.</h3>
                <p class="is-desines animacija">We are team of profesionals</p>
                <ul>
                    <li><a href="facebook.com"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="instagram.com"><i class="fab fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="karuseles-vidus">
            <div class="karuseles-ft">
                <img src="../app/images/banner.jpg" alt="Banneris">
            </div>
            <div class="centruotas">
                <h2 class="nusileidzia animacija">Meet <span class="bold-upper">Brandi</span>  ! </h2>
                <h3 class="is-kaires animacija"><span class="color">/creative</span> on page template.</h3>
                <p class="is-desines animacija">We are team of profesionals</p>
                <ul>
                    <li><a href="facebook.com"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="instagram.com"><i class="fab fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</section>




<!-- FEUTURES -->
<section class="feutures" id="feutures">
    <div class="container">
        <div class="section-heading">
            <h2>feutures</h2>
            <div class="devider">
                <i class="far fa-heart"></i>
            </div>
        </div>
        <div class="section-content flex-container">
            <div class="icon">
                <i class="far fa-keyboard icona-border"></i>
            </div>
            <div class="feutures">
                <h3>Branding</h3>
                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>
            </div>
            <div class="icon">
                <i class="fas fa-pencil-alt icona-border"></i>
            </div>
            <div class="feutures">
                <h3>Branding</h3>
                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>
            </div>
            <div class="icon">
                <i class="fas fa-bullhorn"></i>
            </div>
            <div class="feutures">
                <h3>Branding</h3>
                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>
            </div>
        </div>
    </div>
</section>
<!-- /FEUTURES -->

<!-- WORKS -->
<section class="works" id="works">
    <div class="container">
        <div class="section-heading">
            <h2>works</h2>
                <div class="devider">
                    <i class="far fa-heart"></i>
                </div>
        </div>
        <div class="section-desc">
            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>
        </div>
        <div class="section-content">
            <ul class="filtras">
                <li><a href="#">All</a></li>
                <li><a href="#">Ecommerce</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Brand</a></li>
            </ul>
        </div>
    </div>
    <div class="filter-content">
        <div class="filtro-elementas">
            <div class="flip">
                <div class="flip-vidus">
                    <div class="flip-priekis">
                        <img src="../app/images/works/item-1.jpg" alt="">
                    </div>
                    <div class="flip-galas">
                        <i class="far fa-eye"></i>
                        <h3>Labore et dolore magnam</h3>
                        <p>Brand</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="filtro-elementas">
            <div class="flip">
                <div class="flip-vidus">
                    <div class="flip-priekis">
                        <img src="../app/images/works/item-2.jpg" alt="">
                    </div>
                    <div class="flip-galas">
                        <i class="far fa-eye"></i>
                        <h3>Labore et dolore magnam</h3>
                        <p>Ecommerce</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="filtro-elementas">
            <div class="flip">
                <div class="flip-vidus">
                    <div class="flip-priekis">
                        <img src="../app/images/works/item-3.jpg" alt="">
                    </div>
                    <div class="flip-galas">
                        <i class="far fa-eye"></i>
                        <h3>Labore et dolore magnam</h3>
                        <p>Ecommerce</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="filtro-elementas">
            <div class="flip">
                <div class="flip-vidus">
                    <div class="flip-priekis">
                        <img src="../app/images/works/item-4.jpg" alt="">
                    </div>
                    <div class="flip-galas">
                        <i class="far fa-eye"></i>
                        <h3>Labore et dolore magnam</h3>
                        <p>Brand</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="filtro-elementas">
            <div class="flip">
                <div class="flip-vidus">
                    <div class="flip-priekis">
                        <img src="../app/images/works/item-5.jpg" alt="">
                    </div>
                    <div class="flip-galas">
                        <i class="far fa-eye"></i>
                        <h3>Labore et dolore magnam</h3>
                        <p>Ecommerce</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- TEAM -->
<section class="team" id="team">
    <div class="container">
        <div class="section-heading">
            <h2>meet our team</h2>
                <div class="devider">
                    <i class="far fa-heart"></i>
                </div>
        </div>
        <div class="section-desc">
            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>
        </div>
        <div class="content">
            <div class="komanda">
                <div class="flip">
                    <div class="flip-vidus">
                        <div class="flip-priekis">
                            <img src="../app/images/member-1.png" alt="">
                        </div>
                        <div class="flip-galas">
                            <h3>voluptatem quila voluptatem</h3>
                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem</p>
                            <a href="http://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                            <a href="http://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            <a href="http://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                    <h2>John Filmr Doe</h2>
                    <p>Managing Director</p>
                </div>
                <div class="flip">
                    <div class="flip-vidus">
                        <div class="flip-priekis">
                            <img src="../app/images/member-2.png" alt="">
                        </div>
                        <div class="flip-galas">
                            <h3>voluptatem quila voluptatem</h3>
                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem</p>
                            <a href="http://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                            <a href="http://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            <a href="http://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                    <h2>Martin Matrone</h2>
                    <p>Lead Developer</p>
                </div>
                <div class="flip">
                    <div class="flip-vidus">
                        <div class="flip-priekis">
                            <img src="../app/images/member-3.png" alt="">
                        </div>
                        <div class="flip-galas">
                            <h3>voluptatem quila voluptatem</h3>
                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem</p>
                            <a href="http://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                            <a href="http://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            <a href="http://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                    <h2>Steve Flaulkin</h2>
                    <p>Sr. UI Designer</p>
                </div>
                <div class="flip">
                    <div class="flip-vidus">
                        <div class="flip-priekis">
                            <img src="../app/images/member-1.png" alt="">
                        </div>
                        <div class="flip-galas">
                            <h3>voluptatem quila voluptatem</h3>
                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem</p>
                            <a href="http://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                            <a href="http://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            <a href="http://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                    <h2>John Filmr Doe</h2>
                    <p>Managing Director</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!--FACTS -->
<section class="facts" id="facts">
    
        <div class="section-heading">
            <h2>some fun facts</h2>
                <div class="devider">
                    <i class="far fa-heart"></i>
                </div>
        </div>
        <div class="container">
            <div class="section-content">
                <div class="gridas">
                    <div class="laikas">
                        <i class="far fa-clock"></i>
                        <div class="counter" data-target="3200">3200</div>
                        <h3>HOURS OF WORK</h3>
                    </div>
                    <div class="grupe">
                        <i class="fas fa-users"></i>
                        <div class="counter" data-target="120">0</div>
                        <h3>SATISFIED CLIENTS</h3>
                    </div>
                    <div class="raketa">
                        <i class="fas fa-rocket"></i>
                        <div class="counter" data-target="360">0</div>
                        <h3>PROJECTS DELIVERED</h3>
                    </div>
                    <div class="taure">
                        <i class="fas fa-trophy"></i>
                        <div class="counter" data-target="6454">0</div>
                        <h3>AWARDS WON</h3>
                    </div>
                </div>
            </div>
        </div>
</section>


<!-- DISCUSS -->
<section class="discuss" id="contact">
    <div class="container">
        <div class="section-heading">
            <h2>let's discuss</h2>
                <div class="devider">
                    <i class="far fa-heart"></i>
                </div>
        </div>
        <div class="section-desc">
            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>
        </div>
        <div class="gridas-formos">
            <div class="adresas">
                <h2>Cras at ultrices erat, sed vulputate</h2>
                <p>2345 Setwant natrer, 1234,</p>
                <p>Washington. United States.</p>
                <p>(401) 1234 567</p>
            </div>
            <div class="forma">
                <div class="formos-gridas">
                    <h2>Say Hello !</h2>
                    <form action="../app/src/app.php" class="contact-form" method="post">
                        <div class="input-group">
                            <div class="input-field">
                                <input class="name form-control" type="text" name="name" placeholder="Name" required>
                            </div>
                            <div class="input-field">
                                <input class="email form-control" type="email" name="email" placeholder="Email" required>
                            </div>
                        </div>
                        <div class="input-group">
                            <textarea name="message" class="form-control" id="message" cols="30" rows="8" placeholder="Message" required></textarea>
                        </div>
                        <div class="input-group">
                            <input type="submit" name="submit" id="form-submit" class="pull-right" value="Send Message">
                            <!-- <button name="submit" class="btn-form"><i class="far fa-envelope"></i>Send Message</button> -->
                        </div>
                    </form>
                </div>
            </div>
            <div class="soc">
                <i class="fab fa-behance"></i>
                <i class="fab fa-twitter"></i>
                <i class="fab fa-dribbble"></i>
                <i class="fab fa-facebook-f"></i>
            </div>
        </div>
    </div>
</section>
</main>
